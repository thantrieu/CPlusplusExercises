#include <string>
#include <iostream>
#include "Employee.h"
using namespace std;

Employee::Employee() {}

Employee::Employee(string id) :id(id) {}

void Employee::setId(string id) { this->id = id; }

string Employee::getId() const { return id; }

void Employee::setFullName(string fullName) { this->fullName = fullName; }

string Employee::getFullName() const { return fullName; }

void Employee::setDateOfBirth(string dateOfBirth) { this->dateOfBirth = dateOfBirth; }

string Employee::getDateOfBirth() const { return dateOfBirth; }

void Employee::setGender(string gender) { this->gender = gender; }

string Employee::getGender() const { return gender; }

void Employee::setEmail(string email) { this->email = email; }

string Employee::getEmail() const { return email; }

void Employee::setSalary(long salary) { this->salary = salary > 0 ? salary : 0; }

long Employee::getSalary() const { return salary; }

void Employee::showInfo() const {
	cout << "Ma nhan vien: " << id << endl;
	cout << "Ho va ten: " << fullName << endl;
	cout << "Dia chi mail: " << email << endl;
	cout << "Ngay sinh: " << dateOfBirth << endl;
	cout << "Gioi tinh: " << gender << endl;
	cout << "Luong: " << salary << endl;
}