#include <iostream>
#include "Tester.h"
using namespace std;

Tester::Tester() {}

void Tester::showInfo() const {
	Employee::showInfo();
	cout << "Cong cu lam viec: " << testTool << endl;
}

void Tester::setTestTool(string testTool) { this->testTool = testTool; }

string Tester::getTestTool() const { return testTool; }