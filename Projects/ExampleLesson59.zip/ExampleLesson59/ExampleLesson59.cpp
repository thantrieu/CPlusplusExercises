#include <iostream>
#include "Tester.h"
using namespace std;

Tester createTester() {
	string id;
	string fullName;
	string email;
	string gender;
	string dob;
	long salary;
	string testTool;

	cout << "Nhap so CMND/CC/HC: ";
	getline(cin, id);
	cout << "Ho va ten: ";
	getline(cin, fullName);
	cout << "Nhap so email: ";
	getline(cin, email);
	cout << "Nhap ngay sinh: ";
	getline(cin, dob);
	cout << "Nhap Gioi tinh: ";
	getline(cin, gender);
	cout << "Nhap luong: ";
	cin >> salary;
	cin.ignore();
	cout << "Nhap cong cu lam viec: ";
	getline(cin, testTool);

	Tester tester;
	tester.setId(id);
	tester.setFullName(fullName);
	tester.setSalary(salary);
	tester.setDateOfBirth(dob);
	tester.setGender(gender);
	tester.setEmail(email);
	tester.setTestTool(testTool);
	return tester;
}

int main()
{
	Tester testers[100];
	int testerSize = 0;

	int choice;
	do {
		cout << "============= MENU =============\n";
		cout << "1. Them moi tester\n";
		cout << "2. Hien danh sach tester hien co\n";
		cout << "0. Thoat chuong trinh\n";
		cout << "Xin moi chon: " << endl;
		cin >> choice;
		cin.ignore();
		switch (choice)
		{
		case 0:
			cout << "Xin chao va hen gap lai!\n";
			break;
		case 1: {
			testers[testerSize++] = createTester();
			break;
		}
		case 2: {
			if (testerSize == 0) {
				cout << "Danh sach rong!" << endl;
			}
			else {
				cout << "=============== DANH SACH TESTER ===============\n";
				for (int i = 0; i < testerSize; i++)
				{
					testers[i].showInfo();
					cout << "-------------------------------------\n";
				}
			}
			break;
		}
		default:
			cout << "Vui long chon chuc nang tu 0->2.\n";
			break;
		}
	} while (choice != 0);
}