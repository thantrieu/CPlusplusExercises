#pragma once
class Date
{
	int day;
	int month;
	int year;
public:
	Date(int = 1, int = 1, int = 1900);
	void showDate() const;
	void setDay(int day);
	int getDay() const;
	void setMonth(int month);
	int getMonth() const;
	void setYear(int year);
	int getYear() const;
};

