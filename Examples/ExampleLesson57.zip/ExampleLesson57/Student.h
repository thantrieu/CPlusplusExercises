#pragma once
#include <string>
#include "Date.h"
using namespace std;

class Student
{
	string id;
	string fullName;
	Date dateOfBirth;
	float averageGrade;
public:
	Student();
	Student(string, string, Date, float);
	void showStudentInfo() const;
};

