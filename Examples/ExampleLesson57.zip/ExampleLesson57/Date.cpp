#include <iostream>
#include <iomanip>
#include "Date.h"
using namespace std;

Date::Date(int day, int month, int year): day(day), month(month), year(year) {}

void Date::showDate() const {
	cout << setfill('0') << setw(2) << day << "/"
		<< setw(2) << month << "/" << setw(2) << year << endl;
}

void Date::setDay(int day) {
	int dayOfMonths[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	if (day > 0 && day <= dayOfMonths[month]) {
		this->day = day;
	}
	else {
		this->day = 1;
	}
}

int Date::getDay() const {
	return day;
}

void Date::setMonth(int month) {
	this->month = (month > 0 && month <= 12) ? month : 1;
}

int Date::getMonth() const {
	return month;
}

void Date::setYear(int year) {
	this->year = (year >= 1900 && year <= 2050) ? year : 1900;
}

int Date::getYear() const {
	return year;
}