#include <iostream>
#include <string>
#include "Student.h"
using namespace std;

Student::Student() {}

Student::Student(string id, string fullName, Date dob, float averageGrade) :
	id(id), fullName(fullName), dateOfBirth(dob), averageGrade(averageGrade) {}

void Student::showStudentInfo() const {
	cout << "ID: " << id << endl;
	cout << "Full name: " << fullName << endl;
	cout << "Date of birth: ";
	dateOfBirth.showDate();
	cout << "Average grade: " << averageGrade << endl;
}