#include <iostream>
#include <string>
#include "Student.h"
using namespace std;


int main()
{
	Date dob(15, 9, 2000);
	Date dob2(22, 1, 2001);
	Student thuy("B20DCCN121", "Le Thanh Thuy", dob, 3.54f);
	Student phong("B21DCCN121", "Ngo Thanh Phong", dob2, 3.75f);
	thuy.showStudentInfo();
	cout << "==============================\n";
	phong.showStudentInfo();

	return 0;
}